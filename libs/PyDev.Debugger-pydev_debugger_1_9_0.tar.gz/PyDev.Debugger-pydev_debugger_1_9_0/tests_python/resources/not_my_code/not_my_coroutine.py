

async def call1(callback):
    await callback()

