

def call_me_back1(callback):
    a = 'other'
    callback()
    return a
